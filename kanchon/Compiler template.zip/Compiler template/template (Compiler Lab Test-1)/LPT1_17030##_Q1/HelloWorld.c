#include<stdio.h>

/*
ROLL: 17030##
FULL QUESTION: 

*/

int main()
{
    printf("HELLO WORLD");
}