#include<stdio.h>
int main(){
    int x = 2;
    int y = 3;
    int z = x + y;

    printf("z = %d\n", z);
    return 0;
}